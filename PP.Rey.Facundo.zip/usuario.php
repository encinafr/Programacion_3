<?PHP
class Usuario
{
    var $nombre;
    var $clave;

    public function __construct($par_1, $par_2)
	{
        $this->nombre=$par_1;
        $this->clave=$par_2;
    }

    static function leer($archivo)
    {
        $lista = array();
        if(file_exists($archivo)){
            $ar = fopen($archivo, 'r');
            while(!feof($ar)){
                array_push($lista,fgets($ar));
            }
            fclose($ar);
            $usuarios = array();    
            foreach ($lista as $usuario) {
                $datos = explode(";",$usuario);
                if($datos[0]!=NULL)
                    array_push($usuarios, new Usuario($datos[0],rtrim($datos[1])));
            } 
            return $usuarios;
        }
        return $lista; 
    }
    
    public function crearUsuario()
    {
        $listaUsuarios = self::leer("usuarios.txt");
        foreach($listaUsuarios as $usuario){
            if($usuario->nombre == $this->nombre)
                return;
        }
        array_push($listaUsuarios, $this);
        $ar = fopen("usuarios.txt", 'w');
        foreach($listaUsuarios as $usuario)
            fwrite($ar,$usuario->nombre.";".$usuario->clave.PHP_EOL);
        fclose($ar);
    }

    public static function login()
    {
        $listaUsuarios = self::leer("usuarios.txt");
        foreach($listaUsuarios as $usuario){
            if($usuario->nombre == $_POST["nombre"]){
                if($usuario->clave == $_POST["clave"]){
                    echo 'Acceso!';   
                    return true;
                }
                else
                    echo 'Clave incorrecta.';
                    return false;
            }          
        }
        echo 'Nombre incorrecto.';
        return false;
    }

    public static function listarUsuarios()
    {
        $listaUsuarios = self::leer("usuarios.txt");
        foreach($listaUsuarios as $usuario){
            if($usuario->nombre == $_GET["nombre"]){
                echo $usuario->nombre.";".$usuario->clave;
                return $usuario->nombre.";".$usuario->clave;
            }          
        }
        echo 'No existe '.$_GET["nombre"];
        return 'No existe '.$_GET["nombre"];
    }
}
?>