<?PHP
include './usuario.php';
include './producto.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
    switch($_GET["caso"]){
    case "crearUsuario":
        $usuario = new Usuario($_POST["nombre"],$_POST["clave"]);
        $usuario->crearUsuario();
        break;
    case "login":
        Usuario::login();
        break;
    case "cargarProducto":
        $producto = new Producto($_POST["id"],$_POST["nombre"],$_POST["precio"],$_FILES["imagen"]["tmp_name"],$_POST["nUsuario"]);
        $producto->cargarProducto();
        break;
    case "modificarProducto":
        $producto = new Producto($_POST["id"],$_POST["nombre"],$_POST["precio"],$_FILES["imagen"]["tmp_name"],$_POST["nUsuario"]);
        $producto->modificarProducto();
        break;
    }
}

if($_SERVER['REQUEST_METHOD']=='GET'){
    switch($_GET["caso"]){
    case "listarUsuarios":
        Usuario::listarUsuarios();
        break;
    case "listarProductos":
        if(isset($_GET["criterio"]) && isset($_GET["valor"]))
            Producto::listarProductosCriterio($_GET["criterio"],$_GET["valor"]);
        else
            Producto::listarProductos();
        break;
    }
}
?>