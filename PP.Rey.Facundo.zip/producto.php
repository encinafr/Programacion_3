<?PHP
class Producto
{
    var $id;
    var $nombre;
    var $precio;
    var $imagen;
    var $nUsuario;

    public function __construct($id, $nombre,$precio,$imagen,$nUsuario)
	{
        $this->id=$id;
        $this->nombre=$nombre;
        $this->precio=$precio;
        $this->imagen=$imagen;
        $this->nUsuario=$nUsuario;
    }

    static function leer($archivo)
    {
        $lista = array();
        if(file_exists($archivo)){
            $ar = fopen($archivo, 'r');
            while(!feof($ar)){
                array_push($lista,fgets($ar));
            }
            fclose($ar);
            $productos = array();    
            foreach ($lista as $producto) {
                $datos = explode(";",$producto);
                if($datos[0]!=NULL)
                    array_push($productos, new Producto($datos[0],$datos[1],$datos[2],$datos[3],rtrim($datos[4])));
            } 
            return $productos;
        }
        return $lista; 
    }

    function imprimir()
    {
        echo $this->id.";".$this->nombre.";".$this->precio.";".$this->imagen.";".$this->nUsuario.PHP_EOL;
    }

    public function cargarProducto()
    {
        $ruta = ".\\Fotos\\".$this->id.".".explode(".",$_FILES["imagen"]["name"])[1];
        move_uploaded_file($this->imagen, $ruta);
        $this->imagen = $ruta;
        $listaProductos = self::leer("productos.txt");
        array_push($listaProductos, $this);
        $ar = fopen("productos.txt", 'w');
        foreach($listaProductos as $producto)
            fwrite($ar,$producto->id.";".$producto->nombre.";".$producto->precio.";".$producto->imagen.";".$producto->nUsuario.PHP_EOL);
        fclose($ar);
    }

    public function listarProductos()
    {
        $listaProductos = self::leer("productos.txt");
        foreach($listaProductos as $producto)
            $producto->imprimir();
    }

    public function listarProductosCriterio($criterio, $valor)
    {
        $listaProductos = self::leer("productos.txt");
        switch($criterio){
        case "producto":
            foreach($listaProductos as $producto){
                if($producto->nombre == $valor)    
                    $producto->imprimir();
            }
            break;
        case "usuario":
        foreach($listaProductos as $producto){
            if($producto->nUsuario == $valor)    
                $producto->imprimir();
        }
            break;
        }
    } 
    
    public function modificarProducto()
    {
        $listaProductos = self::leer("productos.txt");
        foreach($listaProductos as $key => $producto){
            if($this->id==$producto->id){
                $producto->nombre=$this->nombre;
                $producto->precio=$this->precio;
                $producto->nUsuario=$this->nUsuario;
                $ruta = ".\\Fotos\\".$this->id.".".explode(".",$_FILES["imagen"]["name"])[1];
                $producto->imagen=$ruta;
                if(file_exists($ruta))
                    rename($ruta, ".\\backUpFotos\\".$this->id.".".date("d M Y").".jpg");
                move_uploaded_file($this->imagen, $ruta);            
                $ar = fopen("productos.txt", 'w');
                foreach($listaProductos as $producto)
                    fwrite($ar,$producto->id.";".$producto->nombre.";".$producto->precio.";".$producto->imagen.";".$producto->nUsuario.PHP_EOL);
                fclose($ar);
                return;
            }       
        }
        echo "No se encontró el id del producto a modificar.";
    }
}
?>